#ifndef _GAMECONSTANTS_H
#define _GAMECONSTANTS_H

extern int drawMode;
extern float rotationAngle;


#endif